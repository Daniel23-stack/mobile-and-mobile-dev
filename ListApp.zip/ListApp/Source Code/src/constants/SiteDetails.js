export default {
	app_key: 'TdBezB1nU2SbcF2NwsIXHBotsf2OiY',

	url: 'https://townhub.cththemes.com',
	terms_page: 'https://townhub.cththemes.com/help-center/',
}

export const defaultLanguage = {
	code: 'en',
	rtl: false
}
export const defaultCurrency = 'USD';