import RegisterScreen from '../RegisterScreen';
export default class Register extends RegisterScreen {}