How to view ?

- If you are on Windows, make sure to download and install Git for Windows and optionally Console2. You will be executing any commands in this guide in the Git Bash or Console2 windows.

- 
Make sure you have Node.js (https://nodejs.org/) installed, then run

$ sudo npm install -g ionic

and :

$ ionic serve

Read more :
http://ionicframework.com/docs/guide/installation.html
--
Update log:
version 1.2
- add font awesome and Pe-icon-7-stroke
- add scss