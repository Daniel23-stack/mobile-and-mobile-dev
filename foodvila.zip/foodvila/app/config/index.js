const config = {
  theme: 'food',
};

export default config;
